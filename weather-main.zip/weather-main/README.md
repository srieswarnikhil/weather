# this application is developed by using openweathermap api.
# enter /cityname in url to get all weather information of the city.
